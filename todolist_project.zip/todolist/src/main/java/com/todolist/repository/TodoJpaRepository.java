package com.todolist.repository;

import com.todolist.entity.TodoRepository;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TodoJpaRepository extends JpaRepository<TodoRepository,Integer> {
}
