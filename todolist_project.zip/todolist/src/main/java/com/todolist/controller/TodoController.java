package com.todolist.controller;

import com.todolist.entity.TodoRepository;
import com.todolist.service.TodoJpaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/todos")
public class TodoController {

    @Autowired
    private TodoJpaService todoJpaService;

    @GetMapping
    public ResponseEntity<List<TodoRepository>> getAllTodos(){
        List<TodoRepository> todos = todoJpaService.getAllTodos();
        return ResponseEntity.ok(todos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TodoRepository> getTodoById (@PathVariable int id){
        Optional<TodoRepository> todo = todoJpaService.getTodoById(id);
        return todo.map(ResponseEntity::ok).orElseGet(()->ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<TodoRepository> createTodo(@RequestBody TodoRepository todoRepository){
        TodoRepository createTodo = todoJpaService.createOrUpdate(todoRepository);
        return ResponseEntity.status(HttpStatus.CREATED).body(createTodo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TodoRepository> updateTodo(@PathVariable int id,@RequestBody TodoRepository todoRepository){
        todoRepository.setId(id);
        TodoRepository updateTodo =todoJpaService.createOrUpdate(todoRepository);
        return ResponseEntity.ok(updateTodo);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTodo(@PathVariable int id){
        todoJpaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
