package com.todolist.service;

import com.todolist.entity.TodoRepository;
import com.todolist.repository.TodoJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TodoJpaService {

    @Autowired
    private TodoJpaRepository todoJpaRepository;

    public List<TodoRepository> getAllTodos(){
       return todoJpaRepository.findAll();
    }

    public Optional<TodoRepository> getTodoById(int id){
        return todoJpaRepository.findById(id);
    }

    public TodoRepository createOrUpdate(TodoRepository todoRepository){
        return todoJpaRepository.save(todoRepository);
    }

    public void delete(Integer id){
        todoJpaRepository.deleteById(id);
    }
}
